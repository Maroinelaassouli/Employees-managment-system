package com.ests.ems;

import static org.junit.jupiter.api.Assertions.*;

class EmsApplicationTest {

}